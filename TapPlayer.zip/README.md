# TapPlayer
A simple light weight video player for web and mobile browsers. 
