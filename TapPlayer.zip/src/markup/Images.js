export const playSVG = require("../images/play.svg");
export const pauseSVG = require("../images/pause.svg");
export const rewind = require("../images/rewind.svg");
export const replay = require("../images/replay.svg");
export const forward = require("../images/forward.svg");
export const playMain = require("../images/play-main.svg");
export const expand = require("../images/expand.svg");
